import logging

logger = logging.getLogger("django_haystack_opensearch")
