from django.contrib import admin
from unfold.admin import ModelAdmin

from .models import Act, Play, Scene, Speaker, Speech


@admin.register(Speech)
class SpeechAdmin(ModelAdmin):
    list_display = (
        "id",
        "text",
        "speaker",
        "scene",
        "scene__act",
        "scene__act__play",
        "created_date",
    )
    list_filter = ("speaker", "scene", "scene__act", "scene__act__play", "created_date")
    search_fields = (
        "text",
        "speaker__name",
        "scene__name",
        "scene__act__name",
        "scene__act__play__title",
    )
    ordering = ("scene__act__play", "scene__act", "scene", "order")
    list_per_page = 100
    list_max_show_all = 100
    list_display_links = ("id", "text")
    list_select_related = ("speaker", "scene", "scene__act", "scene__act__play")


@admin.register(Play)
class PlayAdmin(ModelAdmin):
    list_display = ("id", "title", "created")
    list_filter = ("created",)
    search_fields = ("title",)
    ordering = ("-created",)
    list_per_page = 100
    list_max_show_all = 100
    list_display_links = ("id", "title")
    list_select_related = ("created",)


@admin.register(Speaker)
class SpeakerAdmin(ModelAdmin):
    list_display = ("id", "name")
    list_filter = ("name",)
    search_fields = ("name",)
    ordering = ("name",)
    list_per_page = 100
    list_max_show_all = 100
    list_display_links = ("id", "name")


@admin.register(Act)
class ActAdmin(ModelAdmin):
    list_display = ("id", "name", "play", "order")
    list_filter = ("play", "order")
    search_fields = ("name", "play__title")
    ordering = ("play", "order")
    list_per_page = 100
    list_max_show_all = 100
    list_display_links = ("id", "name")
    list_select_related = ("play",)


@admin.register(Scene)
class SceneAdmin(ModelAdmin):
    list_display = ("id", "name", "act", "order")
    list_filter = ("act", "order")
    search_fields = ("name", "act__name")
    ordering = ("act", "order")
    list_per_page = 100
    list_max_show_all = 100
    list_display_links = ("id", "name")
    list_select_related = ("act",)
