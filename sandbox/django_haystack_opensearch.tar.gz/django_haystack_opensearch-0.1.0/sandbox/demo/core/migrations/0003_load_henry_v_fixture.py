# Generated migration to load henry_v fixture
# This must run AFTER the fields are added

from django.db import migrations
from django.core.management import call_command

fixture = "henry_v"


def load_fixture(apps, schema_editor):
    call_command("loaddata", fixture, app_label="core")


def unload_fixture(apps, schema_editor):
    Play = apps.get_model("core", "Play")
    Play.objects.filter(title="Henry V").delete()


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0002_add_play_and_speech_fields"),
    ]

    operations = [
        migrations.RunPython(load_fixture, reverse_code=unload_fixture),
    ]


