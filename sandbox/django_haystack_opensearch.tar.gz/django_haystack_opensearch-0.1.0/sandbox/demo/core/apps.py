from django.apps import AppConfig


class CoreConfig(AppConfig):
    name: str = "demo.core"
    label: str = "core"
