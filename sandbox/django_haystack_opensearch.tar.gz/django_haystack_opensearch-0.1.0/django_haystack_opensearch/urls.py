from typing import List  # noqa: UP035

from django.urls import URLPattern, path, re_path

# from .views import

app_name: str = "django_haystack_opensearch"

urlpatterns: List[URLPattern] = []
