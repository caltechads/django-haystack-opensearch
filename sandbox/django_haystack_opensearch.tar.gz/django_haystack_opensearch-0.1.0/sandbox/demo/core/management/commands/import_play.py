import json
import re
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.core.serializers.python import Serializer

from demo.core.models import Act, Play, Scene, Speaker, Speech


class Command(BaseCommand):
    """Import a play text file in the standard format."""

    help = "Import a play text file in the standard format"

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str, help="Path to the play text file")
        parser.add_argument(
            "--title",
            type=str,
            help="Title of the play (if not provided, extracted from filename)",
        )
        parser.add_argument(
            "--output-fixture",
            type=str,
            help="Output fixture file path (if provided, generates fixture instead of saving to database)",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Parse without saving to database",
        )

    def handle(self, *args, **options):
        file_path = Path(options["file_path"])
        if not file_path.exists():
            raise CommandError(f"File not found: {file_path}")

        title = options.get("title")
        if not title:
            # Extract title from filename
            title = file_path.stem.replace("-", " ").replace("_", " ").title()

        output_fixture = options.get("output_fixture")
        dry_run = options.get("dry_run", False)

        self.stdout.write(f"Parsing play: {title}")
        self.stdout.write(f"Reading from: {file_path}")

        # Parse the file
        play_data = self.parse_play_file(file_path, title)

        if output_fixture:
            self.generate_fixture(play_data, output_fixture)
            self.stdout.write(
                self.style.SUCCESS(f"Fixture generated: {output_fixture}")
            )
        elif not dry_run:
            self.save_to_database(play_data)
            self.stdout.write(self.style.SUCCESS("Play imported successfully"))
        else:
            self.stdout.write("Dry run - no data saved")

    def parse_play_file(self, file_path, title):
        """Parse the play text file and return structured data."""
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        play_data = {
            "title": title,
            "acts": [],
        }

        current_act = None
        current_scene = None
        current_speaker = None
        current_speech_lines = []
        act_order = -1  # Start at -1, will be 0 for Prologue
        scene_order = 0
        speech_order = 0
        i = 0

        while i < len(lines):
            line = lines[i].rstrip("\n")
            next_line = lines[i + 1].rstrip("\n") if i + 1 < len(lines) else ""

            # Check for PROLOGUE
            if line == "PROLOGUE" and next_line and all(c == "=" for c in next_line):
                if current_act is not None:
                    # Save previous act
                    play_data["acts"].append(current_act)
                act_order = 0
                scene_order = 0
                speech_order = 0
                current_act = {
                    "name": "Prologue",
                    "order": act_order,
                    "scenes": [],
                }
                current_scene = None
                current_speaker = None
                current_speech_lines = []
                i += 2  # Skip PROLOGUE and underline
                continue

            # Check for ACT N
            act_match = re.match(r"^ACT (\d+)$", line)
            if act_match and next_line and all(c == "=" for c in next_line):
                if current_act is not None:
                    # Save previous act
                    play_data["acts"].append(current_act)
                act_order = int(act_match.group(1))
                scene_order = 0
                speech_order = 0
                current_act = {
                    "name": f"Act {act_order}",
                    "order": act_order,
                    "scenes": [],
                }
                current_scene = None
                current_speaker = None
                current_speech_lines = []
                i += 2  # Skip ACT N and underline
                continue

            # Check for Scene N
            scene_match = re.match(r"^Scene (\d+)$", line)
            if scene_match and next_line and all(c == "=" for c in next_line):
                if current_scene is not None and current_speaker is not None:
                    # Save previous speech
                    if current_speech_lines:
                        current_scene["speeches"].append(
                            {
                                "speaker": current_speaker,
                                "text": "\n".join(current_speech_lines),
                                "order": speech_order,
                            }
                        )
                        speech_order += 1
                        current_speech_lines = []
                if current_act is not None:
                    if current_scene is not None:
                        current_act["scenes"].append(current_scene)
                scene_order = int(scene_match.group(1))
                speech_order = 0
                current_scene = {
                    "name": f"Scene {scene_order}",
                    "order": scene_order,
                    "speeches": [],
                }
                current_speaker = None
                current_speech_lines = []
                i += 2  # Skip Scene N and underline
                continue

            # Skip stage directions (lines in [])
            if line.strip().startswith("[") and line.strip().endswith("]"):
                i += 1
                continue

            # Skip empty lines (but they might separate speakers)
            if not line.strip():
                # If we have a current speech, it might be ending
                if current_speech_lines and current_speaker:
                    # Check if next non-empty line is a new speaker
                    j = i + 1
                    while j < len(lines) and not lines[j].strip():
                        j += 1
                    if j < len(lines):
                        next_non_empty = lines[j].strip()
                        # Check if it's a speaker (ALL CAPS, not stage direction)
                        if (
                            next_non_empty.isupper()
                            and not next_non_empty.startswith("[")
                            and not re.match(r"^(ACT|Scene|PROLOGUE)", next_non_empty)
                        ):
                            # Save current speech and prepare for new speaker
                            if current_scene is not None:
                                current_scene["speeches"].append(
                                    {
                                        "speaker": current_speaker,
                                        "text": "\n".join(current_speech_lines),
                                        "order": speech_order,
                                    }
                                )
                                speech_order += 1
                            current_speech_lines = []
                            current_speaker = None
                i += 1
                continue

            # Ensure we have a scene if we're about to process speeches
            # Some acts (like Prologue or Act 2) don't have explicit Scene markers
            if current_act is not None and current_scene is None:
                # Create a default scene
                scene_order = 1
                current_scene = {
                    "name": "Scene 1",
                    "order": scene_order,
                    "speeches": [],
                }
                speech_order = 0

            # Check if line is a speaker (ALL CAPS, possibly with speech text)
            # Speaker names are in ALL CAPS, but might have speech text after
            stripped = line.strip()
            is_speaker_line = (
                stripped.isupper()
                and not stripped.startswith("[")
                and not re.match(r"^(ACT|Scene|PROLOGUE)", stripped)
            )

            if is_speaker_line:
                # Check if there's speech text on the same line
                # Look for pattern: SPEAKER NAME  speech text (2+ spaces or tab)
                # Try to match speaker name followed by spaces and text
                speaker_match = re.match(
                    r"^([A-Z][A-Z\s&']+?)(?:\s{2,}|\t)(.+)$", line
                )
                if speaker_match:
                    # Speaker name and speech on same line
                    speaker_name = speaker_match.group(1).strip()
                    speech_start = speaker_match.group(2)
                    # Save previous speech if speaker changed
                    if current_speaker and current_speaker != speaker_name:
                        if current_speech_lines and current_scene:
                            current_scene["speeches"].append(
                                {
                                    "speaker": current_speaker,
                                    "text": "\n".join(current_speech_lines),
                                    "order": speech_order,
                                }
                            )
                            speech_order += 1
                        current_speech_lines = []
                    current_speaker = speaker_name
                    current_speech_lines.append(speech_start)
                else:
                    # Just speaker name, no speech on this line
                    speaker_name = stripped
                    # Save previous speech if speaker changed
                    if current_speaker and current_speaker != speaker_name:
                        if current_speech_lines and current_scene:
                            current_scene["speeches"].append(
                                {
                                    "speaker": current_speaker,
                                    "text": "\n".join(current_speech_lines),
                                    "order": speech_order,
                                }
                            )
                            speech_order += 1
                        current_speech_lines = []
                    current_speaker = speaker_name
            else:
                # Regular text line - part of current speech
                if current_speaker and current_scene:
                    current_speech_lines.append(line)

            i += 1

        # Save final speech, scene, and act
        if current_speech_lines and current_speaker and current_scene:
            current_scene["speeches"].append(
                {
                    "speaker": current_speaker,
                    "text": "\n".join(current_speech_lines),
                    "order": speech_order,
                }
            )
        if current_scene and current_act:
            current_act["scenes"].append(current_scene)
        if current_act:
            play_data["acts"].append(current_act)

        return play_data

    def save_to_database(self, play_data):
        """Save parsed play data to database."""
        # Get or create play
        play, created = Play.objects.get_or_create(title=play_data["title"])
        if not created:
            # Delete existing acts and related data
            play.acts.all().delete()

        # Create acts
        for act_data in play_data["acts"]:
            act = Act.objects.create(
                play=play, name=act_data["name"], order=act_data["order"]
            )

            # Create scenes
            for scene_data in act_data["scenes"]:
                scene = Scene.objects.create(
                    act=act, name=scene_data["name"], order=scene_data["order"]
                )

                # Create speeches
                for speech_data in scene_data["speeches"]:
                    speaker, _ = Speaker.objects.get_or_create(
                        name=speech_data["speaker"]
                    )
                    Speech.objects.create(
                        speaker=speaker,
                        scene=scene,
                        text=speech_data["text"],
                        order=speech_data["order"],
                    )

    def generate_fixture(self, play_data, output_path):
        """Generate Django fixture file from parsed play data."""
        fixture_data = []
        pk_counter = 1

        # Create play
        play_pk = pk_counter
        fixture_data.append(
            {
                "model": "core.play",
                "pk": play_pk,
                "fields": {"title": play_data["title"]},
            }
        )
        pk_counter += 1

        # Track pks for foreign keys
        act_pks = {}
        scene_pks = {}
        speaker_pks = {}

        # Create acts
        for act_data in play_data["acts"]:
            act_pk = pk_counter
            act_pks[(act_data["name"], act_data["order"])] = act_pk
            fixture_data.append(
                {
                    "model": "core.act",
                    "pk": act_pk,
                    "fields": {
                        "play": play_pk,
                        "name": act_data["name"],
                        "order": act_data["order"],
                    },
                }
            )
            pk_counter += 1

            # Create scenes
            for scene_data in act_data["scenes"]:
                scene_pk = pk_counter
                scene_pks[(act_pk, scene_data["name"], scene_data["order"])] = scene_pk
                fixture_data.append(
                    {
                        "model": "core.scene",
                        "pk": scene_pk,
                        "fields": {
                            "act": act_pk,
                            "name": scene_data["name"],
                            "order": scene_data["order"],
                        },
                    }
                )
                pk_counter += 1

                # Create speeches
                for speech_data in scene_data["speeches"]:
                    speaker_name = speech_data["speaker"]
                    if speaker_name not in speaker_pks:
                        speaker_pk = pk_counter
                        speaker_pks[speaker_name] = speaker_pk
                        fixture_data.append(
                            {
                                "model": "core.speaker",
                                "pk": speaker_pk,
                                "fields": {"name": speaker_name},
                            }
                        )
                        pk_counter += 1
                    else:
                        speaker_pk = speaker_pks[speaker_name]

                    fixture_data.append(
                        {
                            "model": "core.speech",
                            "pk": pk_counter,
                            "fields": {
                                "speaker": speaker_pk,
                                "scene": scene_pk,
                                "text": speech_data["text"],
                                "order": speech_data["order"],
                            },
                        }
                    )
                    pk_counter += 1

        # Write fixture file
        output_path_obj = Path(output_path)
        output_path_obj.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path_obj, "w", encoding="utf-8") as f:
            json.dump(fixture_data, f, indent=2, ensure_ascii=False)

